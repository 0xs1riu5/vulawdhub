<?php

class SmallToolsAction extends Action
{
    public function weiboShare()
    {
        $this->display();
    }

    public function weiboShow()
    {
        $this->display();
    }

    public function webpageComment()
    {
        $this->display();
    }

    public function bulkFollow()
    {
        $this->display();
    }
}
