<?php

class FeedDelModel extends Model
{
}
