<?php

class FriendModel extends Model
{
}
