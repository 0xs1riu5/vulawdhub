<?php

class UserAppModel extends Model
{
}
