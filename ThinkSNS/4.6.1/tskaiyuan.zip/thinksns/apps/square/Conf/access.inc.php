<?php
/*
 * 游客访问的黑/白名单，不需要开放的，可以注释掉
 */
return array(
    'access' => array(
        'square/Index/index'    => true,
            'square/Index/home' => true,
    ),
);
