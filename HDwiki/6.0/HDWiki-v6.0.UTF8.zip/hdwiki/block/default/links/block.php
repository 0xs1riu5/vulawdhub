<?php
$block['name']='友情链接';
$block['description'] = '友情链接模块';
$block['author']='互动百科';
$block['version']='4.2';
$block['time']='2010-6-30';
$block['fun'] = array(
	'friendlinks'=>'友情链接'
);
?>