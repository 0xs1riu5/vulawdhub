<?php
$block['name']='评论相关';
$block['description']    = '本版块包含对于所有和词条评论相关的调用。';
$block['author']='互动百科';
$block['version']='4.2';
$block['time']='2010-5-12';
$block['fun'] = array(
	'recentcomment'=>'最新评论'
);
?>