<?php
$block['name']='自定义html';
$block['description']='填写js或者html代码';
$block['author']='互动百科';
$block['version']='5.0';
$block['time']='2010-011-08';
$block['fun'] = array(
	'myhtml'=>'添加自定义的html内容。'
);