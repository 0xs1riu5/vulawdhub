var Lang =
{
Login : "登录",
Register: "注册",
Logout : "退出",
sendMessage: "发送短消息",
Loading : "正在加载...",
Subject : "主题",
Content : "内容",
Submit : "提交",
Submiting : "正在提交...",
To : "到",

Success:"成功",

//tip info
TipUserName : "用户名长度最少3位，最多15位!",
TipUserNameNull : "用户名不能为空！",
TipUserNotExist : "用户名不存在!",
TipPassword : "密码不能为空，最多32位!",
TipCode : "验证码不匹配！",
TipMessageLength : "内容最多300个字符",
TipMessageSendOk : "消息发送成功",
TipMessageSendError : "消息发送失败",
TipMessageSubjectIsNull : '请输入消息标题！',
TipMessageContentIsNull : '请输入消息内容！',

TipUcenterLogin : '同步登陆相关应用',

BigImage : '原始图',
BigImageError: '图片大图加载失败！',

Wellcome : "欢迎你，",
Mypms : "我的消息",
Profile : "个人管理",
SystemManage: "系统设置",

EditTag:"编辑标签",
EditTagTip:"多个标签请分隔开，分割符可以使用中英文逗号分号或空格",
EditTagError:"标签编辑失败！",

Fenhao:"；",
Douhao:"，"
}
