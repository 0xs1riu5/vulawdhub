<?php
$member_group=array (
  0 => 
  array (
    'id' => '2',
    'member_group_name' => 'VIP会员',
    'member_group_info' => '注册会员通过管理后台升级的级别',
    'is_disable' => '0',
  ),
  1 => 
  array (
    'id' => '1',
    'member_group_name' => '注册会员',
    'member_group_info' => '注册完成的所有会员都是这个级别',
    'is_disable' => '0',
  ),
);?>