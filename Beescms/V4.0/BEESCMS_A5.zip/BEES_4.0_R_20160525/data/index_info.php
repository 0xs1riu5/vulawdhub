<?php
$_index=array (
  'flash_is' => '0',
  'index_lang' => '9',
);
?>