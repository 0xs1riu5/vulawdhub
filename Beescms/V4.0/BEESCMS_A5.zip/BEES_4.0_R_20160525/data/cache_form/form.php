<?php
$form=array (
  0 => 
  array (
    'id' => '9',
    'form_name' => '留言反馈',
    'form_mark' => 'feedform',
    'is_disable' => '0',
  ),
  1 => 
  array (
    'id' => '8',
    'form_name' => '在线应聘',
    'form_mark' => 'webjob',
    'is_disable' => '0',
  ),
  2 => 
  array (
    'id' => '5',
    'form_name' => '产品购买',
    'form_mark' => 'prinfo',
    'is_disable' => '0',
  ),
);
?>