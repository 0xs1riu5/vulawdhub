<?php
$_sys=array (
  'web_upload_file' => 'zip|gz|rar|iso|doc|xsl|ppt|wps|swf|mpg|mp3|rm|rmvb|wmv|wma|wav|mid|mov',
  'thump_width' => '300',
  'thump_height' => '200',
  'upload_size' => '2024000',
  'web_member' => 
  array (
    0 => '1',
  ),
  'is_member' => 
  array (
    0 => '1',
  ),
  'member_mail' => 
  array (
    0 => '1',
  ),
  'member_no_name' => 'admin|administrator|user|users',
  'image_is' => 
  array (
    0 => '0',
  ),
  'image_url_is' => 
  array (
    0 => '1',
  ),
  'image_type' => 
  array (
    0 => '1',
  ),
  'image_text' => 'www.beescms.com',
  'image_text_color' => '0,0,0',
  'image_text_size' => '12',
  'pic' => 'mark_logo.gif',
  'image_position' => 
  array (
    0 => '9',
  ),
  'mail_type' => 
  array (
    0 => '1',
  ),
  'mail_host' => 'smtp.163.com',
  'mail_pot' => '25',
  'mail_mail' => '',
  'mail_user' => '',
  'mail_pw' => '',
  'mail_js' => '',
  'mail_jw' => 'BEESCMS企业网站管理系统 http://www.beescms.com',
  'safe_open' => 
  array (
    0 => '1',
    1 => '2',
    2 => '3',
  ),
  'web_content_title' => '180',
  'web_content_info' => '200',
  'is_hits' => '1',
  'fialt_words' => '她妈|它妈|他妈|你妈|去死|贱人|非典|艾滋病|阳痿',
  'arc_html' => 
  array (
    0 => '1',
  ),
);
?>