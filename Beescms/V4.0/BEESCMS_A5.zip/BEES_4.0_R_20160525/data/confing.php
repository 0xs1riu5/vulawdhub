<?php
define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASSWORD','');
define('DB_NAME', 'beescms_x2');
define('DB_PRE', 'bees_');
define('DB_PCONNECT', 0);
define('DB_CHARSET', 'utf8');
define('CMS_ADDTIME', 1436276598);
define('CMS_SELF','/beescms_x2/');
?>