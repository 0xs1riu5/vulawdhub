#!/bin/sh

curl --silent --compressed http://example.com/cron.php
